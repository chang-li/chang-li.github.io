function [erate, nvec, y_sign, y_prob] = pcvm_predict(trainX,trainY,testX,testY,w,b,used,width)

weights = w(used).*trainY(used);

% Compute RVM over test data and calculate error
PHI	= ker(testX,trainX(used,:),width);
test_num = size(testX,1);

Y_regress = PHI*weights+b*ones(test_num,1);
y_sign	= sign(Y_regress);

% the probablistic output
y_prob = normcdf(Y_regress); 

errs	= sum(y_sign(testY== -1)~=-1) + sum(y_sign(testY==1)~=1);
erate = errs/test_num;
nvec = length(used);

